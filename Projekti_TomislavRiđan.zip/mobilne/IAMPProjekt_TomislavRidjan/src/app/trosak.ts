export class Trosak {
    id: number;
    title: string;
    description: string;
    iznosTroska: string;
    vrstaTroska: string;
    datumNastanka: Date;
    completed: boolean;
    reminder: string;
}